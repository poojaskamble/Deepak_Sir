<div class="footer_top_agileits">
    <div class="container">
        <div class="col-md-4 footer_grid">
            <h3>About Us</h3>
            <p>Nam libero tempore cum vulputate id est id, pretium semper enim. Morbi viverra congue nisi vel pulvinar posuere sapien
                eros.
            </p>
        </div>
        <div class="col-md-4 footer_grid">
            <h3>Latest News</h3>
            <ul class="footer_grid_list">
                <li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>
                    <a href="#" data-toggle="modal" data-target="#myModal">Lorem ipsum neque vulputate </a>
                </li>
                <li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>
                    <a href="#" data-toggle="modal" data-target="#myModal">Dolor amet sed quam vitae</a>
                </li>
                <li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>
                    <a href="#" data-toggle="modal" data-target="#myModal">Lorem ipsum neque, vulputate </a>
                </li>
                <li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>
                    <a href="#" data-toggle="modal" data-target="#myModal">Dolor amet sed quam vitae</a>
                </li>
                <li><i class="fa fa-long-arrow-right" aria-hidden="true"></i>
                    <a href="#" data-toggle="modal" data-target="#myModal">Lorem ipsum neque, vulputate </a>
                </li>
            </ul>
        </div>
        <div class="col-md-4 footer_grid">
            <h3>Contact Info</h3>
            <ul class="address">
                <li><i class="fa fa-map-marker" aria-hidden="true"></i>8088 USA, Honey block, <span>New York City.</span></li>
                <li><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@example.com">info@example.com</a></li>
                <li><i class="fa fa-phone" aria-hidden="true"></i>+09187 8088 9436</li>
            </ul>
        </div>
        <div class="clearfix"> </div>
        <div class="footer_grids">
            <div class="col-md-4 footer_grid_left">
                <h3>Get notification about <br/>our new releases</h3>
            </div>
            <div class="col-md-8 footer_grid_right">

                <form action="#" method="post">
                    <select class="col-lg-5 textBox">
						<option>SELECT CATEGORY</option>
						<option>Caterhory 1</option>
						<option>SELECT CATEGORY</option>
						<option>SELECT CATEGORY</option>
						<option>SELECT CATEGORY</option>
					</select>
					 <input type="email" name="Email" class="col-lg-5 textBox" placeholder="Enter Email Address..." required="">
                    <input type="submit" class="col-lg-2" value="Submit">
                </form>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
</div>
<div class="footer_w3ls">
    <div class="container">
        <div class="footer_bottom1">
            <p>© 2018 Instruction. All rights reserved | Design by <a href="#">COMPANY NAME</a></p>
        </div>
    </div>
</div>