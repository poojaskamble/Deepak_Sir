<div class="header">
		<div class="content white agile-info">
			<nav class="navbar navbar-default" role="navigation">
				<div class="container-fluid">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
						<a class="navbar-brand" href="index.php">
							<img src="images/logo-png.png">
						</a>
					</div>
					<!--/.navbar-header-->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<nav class="link-effect-2" id="link-effect-2">
							<ul class="nav navbar-nav">
								<li><a href="index.php" class="effect-3">CONSUMER GOODS</a></li>
								<li><a href="category.php" class="effect-3">ICTC &amp; MEDIA</a></li>
								<li><a href="category.php" class="effect-3">MATERIALS AND CHEMICALS</a></li>
								<li class="dropdown">
									<a href="#" class="dropdown-toggle effect-3" data-toggle="dropdown">LIFE SCIENCES  <b class="caret"></b></a>
									<ul class="dropdown-menu">
										<li><a href="category.php">Pharmaceuticals</a></li>
										<li><a href="category.php">Medical Devices &amp; Supplies</a></li>
										<li><a href="category.php">Healthcare</a></li>
										<li><a href="category.php">Diagnostics And Biotech</a></li>
									</ul>
								</li>
								<li><a href="category.php" class="effect-3">MATERIALS AND CHEMICALS</a></li>
							</ul>
						</nav>
					</div>
					<!--/.navbar-collapse-->
					<!--/.navbar-->
				</div>
			</nav>
		</div>
	</div>